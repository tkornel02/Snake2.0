package Game;

import javax.swing.*;
import java.awt.*;

public class PButton extends JButton {

    PButton(String text){
        super(text);
        this.setFont(new Font("Times New Roman",Font.BOLD,17));
        this.setBackground(new Color(1, 211, 3, 255));
        this.setFocusable(false);
    }
}
