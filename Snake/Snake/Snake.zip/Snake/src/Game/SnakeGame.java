package Game;

public class SnakeGame {

    public static void main(String[] args) {
        //new SnakeFrame();
        new MenuFrame();
    }
}