package Game;

import javax.swing.*;
import java.awt.*;

public class MenuFrame extends JFrame {
    MenuButton startButton;
    MenuButton loadButton;
    MenuButton exitButton;

    MenuFrame() {
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setVisible(true);
        this.setResizable(false);
        startButton = new MenuButton("Start Game");
        loadButton = new MenuButton("Load Game");
        exitButton = new MenuButton("Exit");

        JPanel menuPanel = new JPanel(new GridLayout(3,1,20,20));

        menuPanel.add(startButton);
        startButton.addActionListener(e -> new SnakeFrame());
        exitButton.addActionListener(e->this.dispose());
        menuPanel.add(loadButton);
        menuPanel.add(exitButton);
        JPanel fillPanel = new JPanel();
        fillPanel.setPreferredSize(new Dimension(100,500));
        fillPanel.setBackground(new Color(59, 110, 5));
        JPanel fillPanel2 = new JPanel();
        fillPanel2.setPreferredSize(new Dimension(100,500));
        JPanel fillPanel3 = new JPanel();
        fillPanel3.setPreferredSize(new Dimension(500,200));
        this.add(menuPanel,BorderLayout.CENTER);
        this.add(fillPanel,BorderLayout.WEST);
        this.add(fillPanel2,BorderLayout.EAST);
        this.add(fillPanel3,BorderLayout.NORTH);
        for (Component c : this.getContentPane().getComponents()){
            c.setBackground((new Color(59, 110, 5)));
        }



        this.setSize(500,500);
        this.setLocationRelativeTo(null);
    }
}
