package Game;



import javax.swing.*;
import java.awt.*;

public class StatsPanel extends JPanel {
    JLabel scoreLabel;
    JLabel ammoLabel;
    int score;
    int ammo;
    StatsPanel(SnakePanel sp){
        score = sp.snake.score;
        ammo = sp.snake.ammo;
        this.setBackground(Color.white);
        this.setFocusable(false);
        this.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.setBackground(new Color(0,0,0,0));
        scoreLabel = new JLabel("Score: "+score, JLabel.CENTER);
        ammoLabel = new JLabel("Ammo: "+ammo);
        scoreLabel.setForeground(Color.WHITE);
        ammoLabel.setForeground(Color.WHITE);
        this.add(scoreLabel);
        this.add(ammoLabel);
    }
    public void setScoreText(String text){
        scoreLabel.setText(text);
    }
    public void setAmmoText(String text){
        ammoLabel.setText(text);
    }

}
