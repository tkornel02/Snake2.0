package Game;



import javax.swing.*;
import java.awt.*;

public class SnakeFrame extends JFrame {
    private SnakePanel sp;
    SnakeFrame(){
        sp = new SnakePanel(750,400);
        this.setLayout(new BorderLayout());
        SidePanel tp = new SidePanel(this);
        tp.setPreferredSize(new Dimension(200,500));
        this.add(tp,BorderLayout.WEST);
        this.add(sp, BorderLayout.CENTER);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
        this.pack();
        this.setLocationRelativeTo(null);

    }

    public SnakePanel getSp() {
        return sp;
    }
}
