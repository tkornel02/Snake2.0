package Game;

import javax.swing.*;
import java.awt.*;

public class SidePanel extends JPanel {
    PButton startButton;
    PButton exitButton;
    PButton pauseButton;
    PButton changeColorButton;
    SnakeFrame sFrame;
    SidePanel(SnakeFrame sp){
        this.setLayout(new GridLayout(4,1,0,30));
        sFrame = sp;
        this.setBackground(new Color(0, 136, 2, 255));
        this.setFocusable(false);

        startButton = new PButton("Start Game");
        startButton.addActionListener(e -> sFrame.getSp().gameStart());
        pauseButton = new PButton("Pause Game");
        pauseButton.addActionListener(e -> sFrame.getSp().pauseGame());
        exitButton = new PButton("Exit Game");
        exitButton.addActionListener(e -> sFrame.dispose());
        changeColorButton = new PButton("Change Snake Color");
        changeColorButton.addActionListener(new ColorChanger());
        this.add(startButton);
        this.add(pauseButton);
        this.add(changeColorButton);
        this.add(exitButton);
        //this.add(new StatsPanel(sp.getSp()),BorderLayout.EAST);
    }


}
