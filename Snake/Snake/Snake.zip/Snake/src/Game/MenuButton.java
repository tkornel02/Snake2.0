package Game;

import javax.swing.*;
import java.awt.*;

public class MenuButton extends JButton {

    MenuButton(String text){
        super(text);
        setBackground(new Color(255, 255, 255, 255));
        setFocusable(false);
    }
}
