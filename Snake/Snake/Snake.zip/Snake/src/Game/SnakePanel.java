package Game;

import fruits.AmmoFruit;
import fruits.Apple;
import fruits.Fruit;
import projectiles.Projectile;
import snakes.Snake;
import snakes.ZSnake;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

import static java.awt.event.KeyEvent.*;


public class SnakePanel extends JPanel implements ActionListener{

    private static int SCREEN_WIDTH;
    private static int SCREEN_HEIGHT;
    /**Size of Object in Game.SnakePanel*/
    private static final int ITEM_SIZE = 25;

    /**Speed of Game,
     * higher the number, slower the game */
    private static final int DELAY = 60;
    /**Number of units, calculated from SCREEN_HEIGHT and SCREEN_WIDTH*/
    private static int GAME_UNITS;
    /**
     * Game State true if game is
     */
    private static boolean running = false;
    public Snake snake = new Snake(GAME_UNITS);

    public Fruit fruit = new Apple(0,0);
    public int canDo = -1;
    private Random random;
    private final Timer t = new Timer(DELAY,this);
    private final int Z_COUNT = 3;
    boolean gameOver = false;
    private final ArrayList<Projectile> projectiles = new ArrayList<>(GAME_UNITS);
    private final ArrayList<ZSnake> zsnakes = new ArrayList<>(Z_COUNT);

    public static void setScreenWidth(int screenWidth) {
        SCREEN_WIDTH = screenWidth;
    }

    public static void setScreenHeight(int screenHeight) {
        SCREEN_HEIGHT = screenHeight;
    }

    /**
     * Panel to display stats of the game
     */
    StatsPanel stp;
    SnakePanel(int scW,int scH){
        SCREEN_WIDTH = scW;
        SCREEN_HEIGHT = scH;
        GAME_UNITS = (SCREEN_WIDTH/ITEM_SIZE*SCREEN_HEIGHT/ITEM_SIZE);
        this.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());

        JPanel labelPanel = new JPanel(new GridLayout(2,1));


        labelPanel.setBackground(new Color(0,0,0,200));
        stp = new StatsPanel(this);
        this.add(stp);
    }

    /**
     * Starts new Game
     */
    public void gameStart(){
        snake = new Snake(GAME_UNITS);
        canDo = 0;
        running=true;
        projectiles.clear();
        zsnakes.clear();
        random = new Random();
        startSnake();
        generateFruit();
        t.start();
        gameOver = false;
    }

    /**
     * Pauses Game
     */
    public void pauseGame(){
        if (!gameOver)
            running = !running;
    }

    /**
     * Starts the snake at starting position (middle of map)
     */
    public void startSnake() {
        snake.dir = 'R';
        snake.x[0] = (SCREEN_WIDTH/ITEM_SIZE)/2*ITEM_SIZE;
        snake.y[0] = (SCREEN_HEIGHT/ITEM_SIZE)/2*ITEM_SIZE;

        for (int i=1; i < snake.bodyParts; i++){
            snake.x[i] = snake.x[i-1]-ITEM_SIZE;
            snake.y[i] = snake.y[i-1];
        }
    }


    /**
     * Generates Zombie Snake, there are less ZSnakes on the map than Z_COUNT.
     * The direction the ZSnake comes from depends on the canDo variable
     */
    public void generateZSnake(){
        if(zsnakes.size()<Z_COUNT){
            int[] sides = new int[4];
            sides[0] = SCREEN_HEIGHT;
            sides[1] = 0;
            sides[2] = SCREEN_WIDTH;
            sides[3] = 0;
            if (canDo%2==0){
                zsnakes.add(new ZSnake(
                        random.nextInt(0,SCREEN_WIDTH/ITEM_SIZE)*SCREEN_WIDTH/(SCREEN_WIDTH/ITEM_SIZE),
                    sides[random.nextInt(0,2)],
                    'U'));
            }
            else{
                zsnakes.add(new ZSnake(sides[random.nextInt(2,4)],
                        random.nextInt(0,SCREEN_HEIGHT/ITEM_SIZE)*SCREEN_HEIGHT/(SCREEN_HEIGHT/ITEM_SIZE),
                        'R'));
            }
        }
    }

    /**
     * Randomly generates a Fruit in the grid, Fruit type depends on canDo variable
     */
    public void generateFruit(){
        fruit.x = random.nextInt(SCREEN_WIDTH/ITEM_SIZE)*ITEM_SIZE;
        fruit.y = random.nextInt(SCREEN_HEIGHT/ITEM_SIZE)*ITEM_SIZE;

        for (int i=snake.bodyParts; i>=0; i--){
            if (snake.x[i]== fruit.x && snake.y[i] == fruit.y){
                generateFruit();
                System.out.println("Fruit generated on Snake");
            }
        }
        if (canDo %2 == 0 ||  canDo%5 ==0){
            fruit = new AmmoFruit(fruit.x, fruit.y);
        }
        else {
            fruit = new Apple(fruit.x, fruit.y);
        }

    }

    /**
     * Checks Collision of Snake with itself,
     * Snake-Fruit Collision,
     * removes Zombie Snake if it is hit and
     * removes projectile if out of bounds
     */
    public void checkCollision(){
        //Snake Collision (Game Over)
        if (snake.x[0]>=SCREEN_WIDTH || snake.x[0]<0) gameOver();
        else if (snake.y[0]>=SCREEN_HEIGHT  || snake.y[0]<0) gameOver();
        for (int i = 1; i< snake.bodyParts; i++){
            if (snake.x[0] == snake.x[i] &&
                    snake.y[0] == snake.y[i])
                gameOver();
        }
        //Snake Fruit collision
        if(snake.x[0]==fruit.x && snake.y[0]==fruit.y) {fruit.eatenBy(snake); generateFruit();
            //System.out.println("Fruit: "+fruit.x+" "+fruit.y);
            }

        //Projectile collision with ZSnake or Out of Bounds Projectile
        projectiles.removeIf(p -> (p.x > SCREEN_WIDTH || p.x < 0 || p.y < 0 || p.y > SCREEN_HEIGHT) || p.hit);
        zsnakes.removeIf(this::checkProjectileHit);
    }

    /**
     * Checks if a Zombie Snake and the Snake collides
     */
    public void checkSnakeZSnakeCollision(){
        for (ZSnake zs : zsnakes){
            for (int i=0; i < snake.bodyParts; i++){
                if(zs.zX[0] == snake.x[i] && zs.zY[0] == snake.y[i]){
                    if(i==0){
                        gameOver();
                        //System.out.println("x: " + zs.zX[0] + " == " +snake.x[i] + " y: " + zs.zY[0] + " == " +snake.y[i]);
                    }
                    else {
                        snake.bodyParts = i;
                    }
                }
            }
        }
    }

    /**
     * @param zsnake
     * Checks if ZSnake has been hit with Projectile
     * @return true if ZSnake is hit
     */
    boolean checkProjectileHit(ZSnake zsnake){
            for (int j = 0; j < ZSnake.Z_LENGTH; j++){
                for(Projectile p : projectiles){
                    if(zsnake.zX[j] == p.x && zsnake.zY[j]==p.y){
                        p.hit = true;
                        snake.score+=2;
                        return true;
                    }
                }
            }
        return false;
    }

    /**
     * Stops the Game
     */
    public void gameOver(){
        running = false;
        gameOver = true;
        canDo = -2;
    }

    /**
     * @param g the <code>Graphics</code> object to protect
     */
    @Override
    public void paintComponent(Graphics g){
            super.paintComponent(g);
            draw(g);

    }

    /**
     * @param g draws all the Objects in the Panel (Grid, Snakes, Fruits, texts)
     */
    public void draw(Graphics g) {
        if (canDo >= 0){
            g.setColor(new Color(100, 100, 100, 50));
            for (int i = 0; i <= SCREEN_WIDTH / ITEM_SIZE; i++) {
                g.drawLine(i * ITEM_SIZE, 0, i * ITEM_SIZE, SCREEN_HEIGHT);
            }
            for (int i = 0; i <= SCREEN_HEIGHT / ITEM_SIZE; i++) {
                g.drawLine(0, i * ITEM_SIZE, SCREEN_WIDTH, i * ITEM_SIZE);
            }

            g.setColor(Color.green);
            for (int i = 0; i<snake.bodyParts;i++) {
                if (i==0) {
                    g.setColor(Snake.color);
                    g.fillRect(snake.x[i], snake.y[i], ITEM_SIZE, ITEM_SIZE);
                }
                else{
                    g.setColor(Snake.color);
                    //g.setColor(new Color(random.nextInt(0,255),random.nextInt(0,255),random.nextInt(0,255)));
                    g.fillRect(snake.x[i], snake.y[i], ITEM_SIZE, ITEM_SIZE);
                }
            }
            g.setColor(Color.red);
            for (Projectile projectile : projectiles) {
                g.fillRect(projectile.x, projectile.y, ITEM_SIZE, ITEM_SIZE);
            }

            g.setColor(fruit.c);
            g.fillOval(fruit.x,fruit.y,ITEM_SIZE,ITEM_SIZE);

            g.setColor(new Color(100, 15, 173));
            for (ZSnake zsnake : zsnakes) {
                for (int j = 0; j < ZSnake.Z_LENGTH; j++){
                    g.fillRect(zsnake.zX[j], zsnake.zY[j], ITEM_SIZE, ITEM_SIZE);

                }
            }
        }
        else if (canDo==-1){
            String startGameStr = "Press Start to play!";
            g.setColor(Color.WHITE);
            g.setFont(new Font("Times New Roman",Font.BOLD, 30));
            g.drawString(startGameStr,getWidth()/2-g.getFontMetrics().stringWidth(startGameStr)/2,getHeight()/2);

        }
        else if(gameOver){
            String endGameStr = "Final Score: "+snake.score;
            g.setColor(Color.RED);
            g.setFont(new Font("Times New Roman",Font.BOLD, 30));
            g.drawString(endGameStr,getWidth()/2-g.getFontMetrics().stringWidth(endGameStr)/2,getHeight()/2);
        }
    }

    /**
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(running){
            if (canDo %2==0){
                snake.move(ITEM_SIZE);
                //System.out.println("x: " +snake.x[0] + " y: "  +snake.y[0]);
            }
            if (canDo %3==0){
                for (ZSnake z : zsnakes){
                    z.moveZ(snake.x,snake.y,random, ITEM_SIZE);
                    //System.out.println("zX: " +z.zX[0] + " zY: "  +z.zY[0]);
                }
            }
            for (Projectile p : projectiles){
                p.moveProj(ITEM_SIZE);
            }
            if (canDo%100==0){generateZSnake();}
            canDo++;

            checkCollision();
            checkSnakeZSnakeCollision();
            repaint();
        }
        stp.setScoreText("Score: "+ snake.score);
        stp.setAmmoText("Ammo: "+ snake.ammo);


    }


    /**
     * KeyAdapter for Control
     */
    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e){
            switch(e.getKeyCode()){
                case VK_W: if (snake.dir != 'D') snake.dir = 'U'; break;
                case VK_S: if (snake.dir != 'U') snake.dir = 'D'; break;
                case VK_D: if (snake.dir != 'L') snake.dir = 'R'; break;
                case VK_A: if (snake.dir != 'R') snake.dir = 'L'; break;
                case VK_SPACE: if (running)  snake.shoot(ITEM_SIZE,projectiles); break;
                case VK_R: startSnake(); break;
                case VK_B: t.setDelay(t.getDelay()-25);System.out.println(t.getDelay()); break;
                case VK_N: t.setDelay(t.getDelay()+25);System.out.println(t.getDelay()); break;
                case VK_P: generateZSnake(); break;
                case VK_V: zsnakes.clear();
                case VK_K: snake.bodyParts++; break;
                case VK_L: snake.bodyParts--; break;
                case VK_ENTER: running=!running; break;
            }
        }
    }
}
