package projectiles;

public class Projectile{
    public int x;
    public int y;
    public char dir;
    public boolean hit = false;
    public Projectile(int x, int y, char dir){
        this.x = x;
        this.y = y;
        this.dir = dir;
    }
    public void moveProj(int ITEM_SIZE){
        switch (dir) {
            case 'U' -> y = y - ITEM_SIZE;
            case 'D' -> y = y + ITEM_SIZE;
            case 'L' -> x = x - ITEM_SIZE;
            case 'R' -> x = x + ITEM_SIZE;
        }
    }
}