package fruits;

import snakes.Snake;

import java.awt.*;

public class Apple extends Fruit{
    public Apple(int x, int y){
        super(x,y);
        c = Color.RED;
    }



    @Override
    public void eatenBy(Snake snake){
        snake.bodyParts++; snake.score++;
    }
}
