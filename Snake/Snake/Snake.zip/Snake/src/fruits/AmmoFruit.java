package fruits;

import snakes.Snake;

import java.awt.*;

public class AmmoFruit extends Fruit{

    public AmmoFruit(int x, int y){
        super(x,y);
        c = Color.BLUE;
    }
    @Override
    public void eatenBy(Snake snake) {
        snake.ammo+=3;
    }
}
