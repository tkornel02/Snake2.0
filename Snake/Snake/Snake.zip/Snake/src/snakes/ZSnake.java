package snakes;

import java.util.Random;

public class ZSnake{
    public static int Z_LENGTH = 10;
    public int[] zX = new int[Z_LENGTH];
    public int[] zY = new int [Z_LENGTH];
    public char dir;
    public ZSnake(int x, int y, char d){
        zX[0] = x;
        zY[0] = y;
        dir = d;
        for (int i=1;i<Z_LENGTH;i++){
            zX[i]= zX[i-1];
            zY[i]= zY[i-1];

        }
    }
    public char calcMoveX(int[] x, int[] y){
        if (x[0] > zX[0]) return 'R';
        else if(x[0] == zX[0]) {
             if (y[0] < zY[0]) return 'U';
             if (y[0] > zY[0]) return 'D';
        }
        return 'L';
    }
    public char calcMoveY(int[] x, int[] y){
        if (y[0] < zY[0]) return 'U';
        else if (y[0] == zY[0]) {
             if (x[0] > zX[0]) return 'R';
             if (x[0] < zX[0]) return 'L';
        }
        return 'D';
    }


    public void moveZ(int[] x, int[] y, Random random, int ITEM_SIZE) {
        for (int i = Z_LENGTH-1; i > 0; i--) {
            zX[i] = zX[i - 1];
            zY[i] = zY[i - 1];
        }

        char nxtX = calcMoveX(x,y);
        char nxtY = calcMoveY(x,y);
        char [] nxtDirs = new char[3];
        nxtDirs[0] = nxtX;
        nxtDirs[1] = nxtX;
        nxtDirs[2] = nxtY;
        char nxtDir = nxtDirs[random.nextInt(0,3)];
        switch (nxtDir) {
            case 'U' -> zY[0] = zY[0] - ITEM_SIZE;
            case 'D' -> zY[0] = zY[0] + ITEM_SIZE;
            case 'L' -> zX[0] = zX[0] - ITEM_SIZE;
            case 'R' -> zX[0] = zX[0] + ITEM_SIZE;
        }
        //System.out.println("x= "+x[0]+" y= "+y[0]);

    }

}