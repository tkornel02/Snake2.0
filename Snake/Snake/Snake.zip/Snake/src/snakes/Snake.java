package snakes;

import projectiles.Projectile;

import java.awt.*;
import java.util.ArrayList;

public class Snake {
    public static Color color = new Color(1, 211, 3);
    public int[] x;
    public int[] y;
    public int bodyParts = 6;
    public int ammo = 3;
    public int score = 0;
    public char dir = 'R';

    public Snake(int GAME_UNITS){
        x = new int[GAME_UNITS];
        y = new int[GAME_UNITS];
    }
    public void move(int ITEM_SIZE) {
        for (int i = bodyParts; i > 0; i--) {
            x[i] = x[i - 1];
            y[i] = y[i - 1];
        }
        switch (dir) {
            case 'U' -> y[0] = y[0] - ITEM_SIZE;
            case 'D' -> y[0] = y[0] + ITEM_SIZE;
            case 'L' -> x[0] = x[0] - ITEM_SIZE;
            case 'R' -> x[0] = x[0] + ITEM_SIZE;

        }
        //System.out.println("x= "+x[0]+" y= "+y[0]);
    }

    public void shoot(int ITEM_SIZE, ArrayList<Projectile> projectiles) {
        if (ammo > 0) {
            Projectile p = new Projectile(0, 0, 'R');
            switch (dir) {
                case 'U' -> {
                    p.y = y[0] - ITEM_SIZE;
                    p.x = x[0];
                    p.dir = 'U';
                }
                case 'D' -> {
                    p.y = y[0] + ITEM_SIZE;
                    p.x = x[0];
                    p.dir = 'D';
                }
                case 'L' -> {
                    p.x = x[0] - ITEM_SIZE;
                    p.y = y[0];
                    p.dir = 'L';
                }
                case 'R' -> {
                    p.x = x[0] + ITEM_SIZE;
                    p.y = y[0];
                    p.dir = 'R';
                }
            }

            projectiles.add(p);
            ammo--;
        }
    }

}
